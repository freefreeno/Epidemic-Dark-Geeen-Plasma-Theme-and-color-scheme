Epidemic-dark-green-gtk

Matches the Epidemic Plasma theme and color scheme.
