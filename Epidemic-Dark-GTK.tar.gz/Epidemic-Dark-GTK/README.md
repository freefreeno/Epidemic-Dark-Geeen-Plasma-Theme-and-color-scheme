Epidemic-dark-gtk

Matches the Epidemic Plasma theme and color scheme.
